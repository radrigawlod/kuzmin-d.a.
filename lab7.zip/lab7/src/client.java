import java.util.HashMap;

public class client {
    public static void main(String[] args){
        HashMap<Integer, Integer> ht = new HashMap<Integer, Integer>();
        StdOut.println("Вводите числа. 0 - прекратить ввод");
        while(true){
            int str = StdIn.readInt();
            if (str==0) break;
            if (ht.containsKey(str)) ht.put(str, ht.get(str) + 1);
            else ht.put(str, 1);
        }

        HashMap<Integer, Integer> sorted = hash.sort(ht);
        //StdOut.println(sorted);

        for(HashMap.Entry<Integer, Integer> item: sorted.entrySet()){
            StdOut.println("Ключ: "+item.getKey()+", встречается: "+item.getValue()+" раз");
        }
    }
}
