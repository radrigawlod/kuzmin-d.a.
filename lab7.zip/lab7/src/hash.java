import java.util.*;

public class hash {

    public static HashMap<Integer, Integer> sort(HashMap<Integer, Integer> passedMap) {

        List<Integer> mapKeys = new ArrayList<>(passedMap.keySet());
        List<Integer> mapValues = new ArrayList<>(passedMap.values());

        //StdOut.println(mapValues);
        //StdOut.println(mapKeys);

        Collections.sort(mapValues);
        Collections.sort(mapKeys);

        //StdOut.println(mapValues);
        //StdOut.println(mapKeys);

        Collections.reverse(mapValues);
        Collections.reverse(mapKeys);

        //StdOut.println(mapValues);
        //StdOut.println(mapKeys);

        LinkedHashMap<Integer, Integer> sortedMap = new LinkedHashMap<>();
        Iterator<Integer> valueIt = mapValues.iterator();

        while (valueIt.hasNext()) {
            int val = valueIt.next();
            Iterator<Integer> keyIt = mapKeys.iterator();

            while (keyIt.hasNext()) {
                int key = keyIt.next();
                int comp1 = passedMap.get(key);
                int comp2 = val;

                if (comp1==comp2) {
                    keyIt.remove();
                    sortedMap.put(key, val);
                    break;
                }
            }
        }
        return sortedMap;
    }
}
