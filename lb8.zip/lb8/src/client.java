import java.util.Set;

// Кузьмин Д., ИБ-119

public class client {
    public static void main(String[] args) {
        StdOut.println("Введите слово для обработки: ");
        Set<String> res = changes.get(StdIn.readString());
        StdOut.println("\nПолучено " + res.size() + " вариаций (включая исходную фразу)" +
                "\n\nСписок:");
        for (String i: res) {
            StdOut.println(i);
        }
    }
}
