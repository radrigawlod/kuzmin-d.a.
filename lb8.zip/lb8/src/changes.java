import java.util.*;

// Кузьмин Д., ИБ-119

public class changes {

    static Set<String> all;
    static Set<String> inserts;
    static int step=2;

    public static Set<String> get(String string) {
        all = new HashSet<String>(); // класс HashSet как семейство Set может хранить только уникальные значения или null
        char at = string.charAt(0);
        all.add(String.valueOf(at));
        StdOut.println("Шаг 1: \n"+all);
        for (int i = 1; i < string.length(); i++){
            shuffle(string.charAt(i));
        }
        return all;
    }

    private static void shuffle(char c) {
        inserts = new HashSet<>();
        Iterator<String> list = all.iterator();

        StdOut.println("Шаг "+(step++)+":");

        for (int i = 0; i < all.size(); i++) {
            while (list.hasNext()) {
                String temp = list.next();
                for (int z = 0; z <= temp.length(); z++) {
                    StringBuilder sb = new StringBuilder(temp);
                    sb.insert(z, c);
                    inserts.add(sb.toString());
                }
            }
        }

        all = inserts;
        StdOut.println(all);
    }
}
