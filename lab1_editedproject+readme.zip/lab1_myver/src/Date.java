import java.util.Random;

public class Date {
    int day;
    int month;
    int year;

    public Date() {
        int[] rules = {0, 31, 28, 30, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        Random r = new Random();
        month = r.nextInt(12)+1;
        day = r.nextInt(rules[month])+1;
        year = r.nextInt(50)+1970;
    }

    public String toString() {
        String[] names = {
                "нулября",
                "января",
                "февраля",
                "марта",
                "апреля",
                "мая",
                "июня",
                "июля",
                "августа",
                "сентября",
                "октября",
                "ноября",
                "декабря",
        };
        return day + " " + names[month] + " " + year;
    }

}