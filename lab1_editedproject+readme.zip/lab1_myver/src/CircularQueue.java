import java.util.NoSuchElementException;

// Кузьмин Д.А., ИБ-119

public class CircularQueue<Item> {

    private Node first;
    private Node last;
    private int n;
    public int len;

    private class Node<Item> {
        Item item;
        Node next;
        //int id;
    }

    public CircularQueue(int max){
        first=null;
        last=null;
        n=0;
        len=max;
    }

    public boolean isEmpty() {
        return n==0;
    }

    public void size() {
        StdOut.println("\tдлина этой очереди: " + n);
    }

    public void push(Item item) {
        if (n < len) {
            Node<Item> oldlast = last;
            last = new Node<Item>();
            last.item = item;
            last.next = null;
            if (n == 0) {
                first = last;
            }
            else {
                oldlast.next = last;
            }
            n++;
            if (n == len) {
                last.next = first;
            }
            StdOut.println("\tдобавлено: " + item);
        }
        else {
            StdOut.println("\tqueue is full");
        }
    }

    public Item dequeue() {
        //if (n>0) {
        Item item = (Item) first.item;
        first = first.next;
        n--;
        if (n == 0) {
            last = null;
        }
        return item;
        //}
        //else throw new NoSuchElementException("Queue underflow");
    }
}