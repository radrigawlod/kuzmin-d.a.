
// Кузьмин Д.А., ИБ-119

public class client {
    public static void main(String[] args) {
        StdOut.println("Введите размер очереди");
        CircularQueue<String> queue = new CircularQueue<String>(StdIn.readInt());
        StdOut.println("Очередь размером " + queue.len + " из дат создана\n");
        StdOut.println("add - добавить элемент");
        StdOut.println("del - убрать элемент (будет удалён первый элемент)");
        StdOut.println("len - текущая длина очереди");
        StdOut.println("0 - end\n");
        while (true) {
            String item = StdIn.readString();
            if (item.equals("0")) break;
            else if (item.equals("add"))
            {
                Date z = new Date();
                queue.push(z.toString());
            }
            else if (item.equals("del")) {
                if (!queue.isEmpty()) StdOut.println("\tубрано: "+ queue.dequeue());
                else StdOut.println("\tqueue is empty");
            }
            else if (item.equals("len")) queue.size();
            else StdOut.println("\tundefined");
        }
        StdOut.println("завершено");
    }
}

