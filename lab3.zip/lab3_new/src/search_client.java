import java.util.ArrayList;

// Кузьмин Д., ИБ-119

public class search_client {
    public static void main(String[] args) {
        ArrayList<Integer> a = new ArrayList<>(1);
        StdOut.println("Создан массив для ввода чисел");
        while (true) {
            StdOut.println("\nВводите числа. 0 - прекратить ввод");
            while (true) {
                int z = StdIn.readInt();
                if (z != 0) a.add(z);
                else break;
            }
            Heap.sort(a);
            Heap.show(a);
            int size = a.size();
            if (size % 2 == 1)
                StdOut.println("\nn - нечетное;\n\t медиана: " + a.get(size / 2));
            else
                StdOut.println("\nn - четное; \n\tлевая медиана: " + a.get(size / 2 - 1) + "\n\tправая медиана - " + a.get(size / 2));
            StdOut.println("\n0 - продолжить ввод. Любой иной текст - прекратить работу");
            String f = StdIn.readString();
            if (f == "0") continue;
            else break;
        }
    }
}