import java.util.ArrayList;

// Кузьмин Д., ИБ-119

public class Heap {

    public static void sort(ArrayList<Integer> arr) {
        int n = arr.size();

        for (int k = n/2; k >= 1; k--)
            sink(arr, k, n);

        int k = n;
        while (k > 1) {
            exch(arr, 1, k--);
            sink(arr, 1, k);
        }
    }

    private static void sink(ArrayList<Integer> arr, int k, int n) {
        while (2*k <= n) {
            int j = 2*k;
            if (j < n && less(arr, j, j+1)) j++;
            if (!less(arr, k, j)) break;
            exch(arr, k, j);
            k = j;
        }
    }

    private static boolean less(ArrayList<Integer> arr, int i, int j) {
        if (arr.get(i-1)<arr.get(j-1)) return true;
        return false;
    }

    private static void exch(ArrayList<Integer> pq, int i, int j) {
        int swap = pq.get(i-1);
        pq.set(i-1, pq.get(j-1));
        pq.set(j-1, swap);
    }

    public static void show(ArrayList<Integer> arr) {
        StdOut.println("\nСортированное:");
        for (int i = 0; i < arr.size(); i++) {
            StdOut.print(arr.get(i)+ " ");
        }
    }
}
