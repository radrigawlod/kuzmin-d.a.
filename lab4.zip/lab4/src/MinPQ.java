public class MinPQ<Integer> {
    private int[] pq;
    private int N;
    private int cost;

    public MinPQ(int maxN)
    {
        N=0;
        cost=0;
        pq = new int[maxN+1];
    }

    public boolean isEmpty()
    {
        return N==1;
    }

    public void insert(int v)
    {
        pq[++N] = v;
        swim(N);
    }

    public int min()
    {
        return pq[1];
    }

    public int delMin()
    {
        int min = pq[1];
        exch(1,N--);
        sink(1);
        return min;
    }

    private void swim(int k)
    {
        while (k>1 && unless(k/2, k))
        {
            exch(k/2, k);
            k = k/2;
        }
    }

    private void sink(int k)
    {
        while (2*k <= N)
        {
            int j = 2*k;
            if (j<N && unless(j, j+1)) j++;
            if (!unless(k,j)) break;
            exch(k, j);
            k=j;
        }
    }

    protected boolean unless(int a, int b)
    {
        if (pq[a]>pq[b]) return true;
        return false;
    }

    protected void exch(int i, int j)
    {
        int t = pq[i];
        pq[i] = pq[j];
        pq[j] = t;
    }
    public void printQueue()
    {
        StdOut.print("\tДоступные веревки на данном шаге:");
        for (int i = 1; i < N+1; i++) {
            StdOut.print(" "+pq[i]);
        }
        StdOut.println();
    }

    public int SearchCost()
    {
        while (!isEmpty()) {
            int a = delMin();
            int b = delMin();
            int c = a + b;
            cost += c;
            StdOut.println("Соединяем веревки длинами " + a + " и " + b);
            StdOut.println("Стоимость соединения и длина новой веревки: "+c);
            StdOut.println("Общая стоимость соединений: "+cost);
            insert(c);
            printQueue();
            StdOut.println();
        }
        return cost;
    }
}