public class MinPQ_Test {
    public static void main(String[] args) {
        StdOut.println("Введите количество веревок");
        int len = StdIn.readInt();
        MinPQ ropes = new MinPQ(len);
        StdOut.println("Введите длины веревок");
        for (int i = 0; i < len; i++) {
            int a = StdIn.readInt();
            ropes.insert(a);
            StdOut.print("\t Добавлено. Доступные веревки на данном шаге:");
            ropes.printQueue();
        }
        StdOut.println("\n\n*** ИЩЕМ РЕШЕНИЕ ***\n\n");
        int res = ropes.SearchCost();
        StdOut.println("Общая минимальная стоимость объединения: "+res);
        StdOut.println("Длина полученной веревки: "+ropes.min());
    }
}
