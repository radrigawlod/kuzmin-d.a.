public class check_client {

    /*
     Кузьмин Д., ИБ-119
     Проверка и клиент реализованы под тип Date..
     Особых пояснений не требуется..
     */

    public static void main(String[] args) {
        StdOut.println("Проверяется случайное дерево\n" +
                "Порядок вывода: сначала обходится корневое поддерево, затем - левое, затем - правое");
        BSTcheck.Node root = new BSTcheck.Node(new Date());
        root.left = new BSTcheck.Node(new Date());
        root.right = new BSTcheck.Node(new Date());
        root.left.left = new BSTcheck.Node(new Date());
        root.left.right = new BSTcheck.Node(new Date());
        //root.right.left = new BSTcheck.Node(new Date());
        //root.right.right = new BSTcheck.Node(new Date());
        BSTcheck.show(root);
        if (BSTcheck.BST(root, root.left, root.right))
            StdOut.println("Это - дерево бинарного поиска");
        else StdOut.println("Это - не дерево бинарного поиска");
    }
}
























        /*StdOut.println("Выберите вариант проверки: \n" +
                "1 - проверить случайное дерево \n" +
                "2 - вывести ДБП (перебор случайных деревьев)");int z = StdIn.readInt();*/
        /*else if (z==2)
            while(true) {
                BSTcheck.Node root = new BSTcheck.Node(new Date());
                root.left = new BSTcheck.Node(new Date());
                root.right = new BSTcheck.Node(new Date());
                //root.left.left = new BSTcheck.Node(new Date());
                (root.left).right = new BSTcheck.Node(new Date());
                (root.right).left = new BSTcheck.Node(new Date());
                (root.right).right = new BSTcheck.Node(new Date());
                if (BSTcheck.BST(root, root.left, root.right)) {
                    StdOut.println(root.value);
                    StdOut.println(root.left.value);
                    StdOut.println(root.right.value);
                    //StdOut.println((root.left).left.value);
                    StdOut.println((root.left).right.value);
                    StdOut.println((root.right).left.value);
                    StdOut.println((root.right).right.value);
                    System.out.println("Это - дерево бинарного поиска");
                    break;
                }
            }*/
