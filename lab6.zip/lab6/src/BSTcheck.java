public class BSTcheck {

    /*
     Кузьмин Д., ИБ-119
     Проверка и клиент реализованы под тип Date..
     Особых пояснений не требуется..
     */

    static class Node {
        Date value;
        Node left, right;

        public Node(Date value){
            this.value = value;
            this.left = null;
            this.right = null;
            //StdOut.println(this.value);
        }
    }

    static boolean BST(Node root, Node l, Node r) {
        if (root == null)
            return true;
        Date rtd = root.value;
        Date rd = r.value;
        Date ld = l.value;
        if (l != null && rtd.compareTo(ld) < 0)
            return false;
        if (r != null && rtd.compareTo(rd) > 0)
            return false;
        return BST(root.left, l, root) && BST(root.right, root, r);
    }

    public static void show(Node node) {
        if (node != null) {
            System.out.println(node.value);
            show(node.left);
            show(node.right);
        }
    }
}

