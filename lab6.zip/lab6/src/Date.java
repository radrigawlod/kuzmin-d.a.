import java.util.Random;

public class Date implements Comparable<Date> {
    int day;
    int month;
    int year;

    public Date() {
        int[] rules = {0, 31, 28, 30, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        Random r = new Random();
        month = r.nextInt(12)+1;
        day = r.nextInt(rules[month])+1;
        year = r.nextInt(30)+2010;
    }

    public String toString() {
        String[] names = {
                "нулября",
                "января",
                "февраля",
                "марта",
                "апреля",
                "мая",
                "июня",
                "июля",
                "августа",
                "сентября",
                "октября",
                "ноября",
                "декабря",
        };
        return day + " " + names[month] + " " + year;
    }

    @Override
    public int compareTo(Date that)
    {
        if (this.year>that.year) return +1;
        if (this.year<that.year) return -1;
        if (this.month>that.month) return +1;
        if (this.month<that.month) return -1;
        if (this.day>that.day) return +1;
        if (this.day<that.day) return -1;
        return 0;
    }
}